# Sign Language Detection > 2023-07-05 12:47pm
https://universe.roboflow.com/igdtuw-0y0hh/sign-language-detection-xlzhm

Provided by a Roboflow user
License: CC BY 4.0

